
  # Redesign Project Section

  This is a code bundle for Redesign Project Section. The original project is available at https://www.figma.com/design/48krjLORttU5sA6wEzuftn/Redesign-Project-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  